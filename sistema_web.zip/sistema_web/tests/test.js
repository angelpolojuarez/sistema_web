// ============================================================
//  SISTEMA WEB — PRUEBAS AUTOMATIZADAS
//  Archivo: tests/test.js
//  Descripción: Suite de pruebas para validar el despliegue
//               de la página web dentro del pipeline CI/CD.
// ============================================================

const fs   = require('fs');
const path = require('path');

// ── Utilidades de resultado ──────────────────────────────────
let passed = 0;
let failed = 0;
const results = [];

function ok(name) {
  console.log(`  ✓  ${name}`);
  passed++;
  results.push({ test: name, status: 'PASS' });
}

function fail(name, reason) {
  console.error(`  ✗  ${name}`);
  if (reason) console.error(`     → ${reason}`);
  failed++;
  results.push({ test: name, status: 'FAIL', reason });
}

function assert(condition, name, reason) {
  condition ? ok(name) : fail(name, reason);
}

// ── Rutas base ───────────────────────────────────────────────
const ROOT    = path.join(__dirname, '..');
const INDEX   = path.join(ROOT, 'index.html');
const CSS     = path.join(ROOT, 'css', 'styles.css');
const JS      = path.join(ROOT, 'js', 'main.js');
const CIyml   = path.join(ROOT, '.github', 'workflows', 'ci.yml');

// ════════════════════════════════════════════════════════════
//  SUITE 1 — Existencia de archivos clave
// ════════════════════════════════════════════════════════════
console.log('\n📂  Suite 1: Existencia de archivos');

assert(fs.existsSync(INDEX),  'index.html existe',                 'Archivo no encontrado');
assert(fs.existsSync(CSS),    'css/styles.css existe',             'Archivo no encontrado');
assert(fs.existsSync(JS),     'js/main.js existe',                 'Archivo no encontrado');
assert(fs.existsSync(CIyml),  '.github/workflows/ci.yml existe',   'Workflow no encontrado');

// ════════════════════════════════════════════════════════════
//  SUITE 2 — Estructura HTML
// ════════════════════════════════════════════════════════════
console.log('\n🏗️   Suite 2: Estructura HTML');

const html = fs.readFileSync(INDEX, 'utf8');

assert(html.includes('<!DOCTYPE html>'),           'DOCTYPE html declarado');
assert(html.includes('<html'),                     'Etiqueta <html> presente');
assert(html.includes('<head'),                     'Etiqueta <head> presente');
assert(html.includes('<body'),                     'Etiqueta <body> presente');
assert(html.includes('</html>'),                   'Cierre </html> presente');

// ════════════════════════════════════════════════════════════
//  SUITE 3 — Meta tags & SEO básico
// ════════════════════════════════════════════════════════════
console.log('\n🔍  Suite 3: Meta tags & SEO');

assert(html.includes('<meta charset'),             'charset definido');
assert(html.includes('viewport'),                  'Meta viewport presente');
assert(html.includes('<title>'),                   'Etiqueta <title> presente');
assert(html.match(/<title>.+<\/title>/),           'Title tiene contenido');

// ════════════════════════════════════════════════════════════
//  SUITE 4 — Integración de recursos
// ════════════════════════════════════════════════════════════
console.log('\n🔗  Suite 4: Integración de recursos');

assert(html.includes('css/styles.css'),            'CSS vinculado en HTML');
assert(html.includes('js/main.js'),                'JS vinculado en HTML');
assert(html.includes('fonts.googleapis.com'),      'Google Fonts referenciado');

// ════════════════════════════════════════════════════════════
//  SUITE 5 — Contenido semántico
// ════════════════════════════════════════════════════════════
console.log('\n📝  Suite 5: Contenido semántico');

assert(html.includes('<nav'),                      'Elemento <nav> presente');
assert(html.includes('<section'),                  'Secciones <section> presentes');
assert(html.includes('<footer'),                   'Elemento <footer> presente');
assert(html.includes('<h1'),                       'Encabezado <h1> presente');
assert(html.includes('<a '),                       'Elementos de enlace presentes');

// ════════════════════════════════════════════════════════════
//  SUITE 6 — Tamaño y rendimiento básico
// ════════════════════════════════════════════════════════════
console.log('\n⚡  Suite 6: Rendimiento básico');

const htmlSize = fs.statSync(INDEX).size;
const cssSize  = fs.statSync(CSS).size;
const jsSize   = fs.statSync(JS).size;

assert(htmlSize > 0,          'index.html no está vacío');
assert(htmlSize < 500_000,    'index.html < 500 KB');
assert(cssSize  > 0,          'styles.css no está vacío');
assert(jsSize   > 0,          'main.js no está vacío');

// ════════════════════════════════════════════════════════════
//  SUITE 7 — Workflow CI/CD
// ════════════════════════════════════════════════════════════
console.log('\n⚙️   Suite 7: Workflow CI/CD');

const yml = fs.readFileSync(CIyml, 'utf8');

assert(yml.includes('actions/checkout'),           'Step checkout presente');
assert(yml.includes('actions/setup-node'),         'Step setup-node presente');
assert(yml.includes('npm run test'),               'Step de pruebas presente');
assert(yml.includes('gh-pages'),                   'Step de deploy presente');
assert(yml.includes('on:'),                        'Triggers definidos');
assert(yml.includes('push:'),                      'Trigger push configurado');

// ════════════════════════════════════════════════════════════
//  CSS — validaciones básicas
// ════════════════════════════════════════════════════════════
console.log('\n🎨  Suite 8: Hoja de estilos');

const css = fs.readFileSync(CSS, 'utf8');

assert(css.includes(':root'),                      'Variables CSS definidas (--var)');
assert(css.includes('@media'),                     'Media queries responsivas presentes');
assert(css.includes('@keyframes'),                 'Animaciones CSS definidas');
assert(css.length > 500,                           'CSS tiene contenido sustancial');

// ════════════════════════════════════════════════════════════
//  RESUMEN FINAL
// ════════════════════════════════════════════════════════════
const total = passed + failed;
const pct   = Math.round((passed / total) * 100);

console.log('\n' + '═'.repeat(55));
console.log(`  📊  Resultados: ${passed}/${total} pruebas pasadas (${pct}%)`);
if (failed === 0) {
  console.log('  ✅  Todas las pruebas pasaron correctamente.');
} else {
  console.log(`  ❌  ${failed} prueba(s) fallaron.`);
}
console.log('═'.repeat(55) + '\n');

// ── Exportar reporte JSON ──
const reportDir = path.join(ROOT, 'test-results');
if (!fs.existsSync(reportDir)) fs.mkdirSync(reportDir, { recursive: true });

const report = {
  timestamp:   new Date().toISOString(),
  total, passed, failed,
  successRate: `${pct}%`,
  tests: results.filter(r => r.status !== undefined)
};
fs.writeFileSync(
  path.join(reportDir, 'report.json'),
  JSON.stringify(report, null, 2)
);
console.log('  📄  Reporte guardado en: test-results/report.json\n');

// ── Exit code para CI ──
process.exit(failed > 0 ? 1 : 0);
