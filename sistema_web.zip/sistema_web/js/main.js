/* ============================
   SISTEMA WEB — MAIN.JS
   ============================ */

// ── Navbar scroll effect ──
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 40) {
    navbar.style.background = 'rgba(8,12,20,0.97)';
    navbar.style.borderBottomColor = 'rgba(255,255,255,0.12)';
  } else {
    navbar.style.background = 'rgba(8,12,20,0.85)';
    navbar.style.borderBottomColor = 'rgba(255,255,255,0.07)';
  }
});

// ── Active nav link on scroll ──
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      navLinks.forEach(link => link.classList.remove('active'));
      const active = document.querySelector(`.nav-link[href="#${entry.target.id}"]`);
      if (active) active.classList.add('active');
    }
  });
}, { threshold: 0.4 });
sections.forEach(s => observer.observe(s));

// ── Counter animation ──
function animateCounter(el, target, duration = 1500) {
  let start = 0;
  const step = Math.ceil(target / (duration / 16));
  const timer = setInterval(() => {
    start = Math.min(start + step, target);
    el.textContent = start.toLocaleString();
    if (start >= target) clearInterval(timer);
  }, 16);
}

// ── Metric bars & counters on scroll ──
const metricCards = document.querySelectorAll('.metric-card');
const metricObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const card = entry.target;
      const valueEl = card.querySelector('.metric-value');
      const bar = card.querySelector('.metric-fill');
      const target = parseInt(valueEl.dataset.target);
      const delay = parseInt(card.dataset.delay || 0);
      setTimeout(() => {
        animateCounter(valueEl, target);
        if (bar) bar.classList.add('animated');
      }, delay);
      metricObserver.unobserve(card);
    }
  });
}, { threshold: 0.3 });
metricCards.forEach(card => metricObserver.observe(card));

// ── Pipeline steps animation ──
const pipelineSteps = document.querySelectorAll('.pipeline-step');
const pipelineObserver = new IntersectionObserver((entries) => {
  if (entries[0].isIntersecting) {
    pipelineSteps.forEach((step, i) => {
      setTimeout(() => {
        step.style.opacity = '1';
        step.style.transform = 'none';
      }, i * 150);
    });
    pipelineObserver.disconnect();
  }
}, { threshold: 0.2 });
pipelineSteps.forEach(step => {
  step.style.opacity = '0';
  step.style.transform = 'translateY(15px)';
  step.style.transition = 'opacity .4s, transform .4s';
});
if (pipelineSteps[0]) pipelineObserver.observe(pipelineSteps[0].parentElement);

// ── Smooth scroll for anchor links ──
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    e.preventDefault();
    const target = document.querySelector(anchor.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ── Console info ──
console.log('%c SistemaWeb CI/CD ', 'background:#00e5ff;color:#000;font-weight:bold;padding:4px 10px;border-radius:4px;');
console.log('%c GitHub Actions Pipeline activo ✓', 'color:#10b981;font-size:12px;');
console.log('%c Versión 1.0.0 — Tests: 6/6 passed', 'color:#7a8a9e;font-size:11px;');
