# 🚀 SistemaWeb — CI/CD con GitHub Actions

Página web con pipeline completo de integración y despliegue continuo (CI/CD) usando **GitHub Actions** y **GitHub Pages**.

---

## 📁 Estructura del Proyecto

```
sistema_web/
├── index.html                    ← Página principal
├── css/
│   └── styles.css                ← Estilos
├── js/
│   └── main.js                   ← JavaScript
├── tests/
│   └── test.js                   ← Suite de pruebas automatizadas
├── test-results/
│   └── report.json               ← Reporte generado por los tests
├── .github/
│   └── workflows/
│       └── ci.yml                ← Pipeline CI/CD
├── package.json
└── README.md
```

---

## ⚙️ Configuración del Pipeline CI/CD

### Pasos para activarlo en GitHub:

1. **Crear repositorio** en GitHub (ej: `sistema-web`)
2. **Subir los archivos** al repositorio:
   ```bash
   git init
   git add .
   git commit -m "feat: initial commit"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/sistema-web.git
   git push -u origin main
   ```
3. **Activar GitHub Pages**:
   - Ve a `Settings → Pages`
   - Source: `Deploy from a branch`
   - Branch: `gh-pages` / `/ (root)`
4. **Ir a Actions** → Verás el pipeline ejecutándose automáticamente

---

## 🧪 Pruebas Automatizadas

El archivo `tests/test.js` contiene **8 suites** de prueba:

| Suite | Descripción | Tests |
|-------|-------------|-------|
| 1 | Existencia de archivos clave | 4 |
| 2 | Estructura HTML válida | 5 |
| 3 | Meta tags & SEO básico | 4 |
| 4 | Integración de recursos | 3 |
| 5 | Contenido semántico | 5 |
| 6 | Rendimiento básico | 4 |
| 7 | Workflow CI/CD | 6 |
| 8 | Hoja de estilos | 4 |

**Total: 35 pruebas automatizadas**

Para correr las pruebas localmente:
```bash
npm install
npm run test
```

---

## 🔄 Flujo del Pipeline

```
git push → GitHub Actions → Tests → Deploy (GitHub Pages)
```

1. `📥 Checkout` — Descarga el código
2. `🟢 Setup Node.js` — Configura entorno v20
3. `📦 Install` — Instala dependencias
4. `🧪 Tests` — Ejecuta suite de pruebas
5. `📊 Reporte` — Guarda artefacto JSON
6. `🚀 Deploy` — Publica en GitHub Pages

---

## 📊 Análisis de Resultados

Cada ejecución del pipeline genera un `test-results/report.json`:

```json
{
  "timestamp": "2025-01-01T00:00:00.000Z",
  "total": 35,
  "passed": 35,
  "failed": 0,
  "successRate": "100%",
  "tests": [...]
}
```

Los reportes se guardan como **artefactos de GitHub Actions** por 30 días, permitiendo medir el despliegue a lo largo del tiempo.

---

## 🛠 Tecnologías

- **HTML5 / CSS3 / JavaScript** — Frontend
- **Node.js** — Runner de pruebas
- **GitHub Actions** — CI/CD Pipeline
- **GitHub Pages** — Hosting gratuito
- **peaceiris/actions-gh-pages** — Action de deploy
